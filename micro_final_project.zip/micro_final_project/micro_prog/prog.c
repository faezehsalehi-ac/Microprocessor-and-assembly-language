/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 6/2/2018
Author  : 
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/
#include <math.h>
#include <mega32.h>
#include <stdlib.h>
#include <string.h>


// Graphic Display functions
#include <glcd.h>

// Font used for displaying text
// on the graphic display
#include <font5x7.h>

// Declare your global variables here

#include <delay.h>
int counter=0;
int second1=0;
int second2=0;
char str[10];
interrupt [TIM2_OVF] void timer2_ovf_isr(void)
{
	counter++;
	if(counter ==3906){
		second1++;
        second2++;
		counter=0;
        itoa(second2,str);
        glcd_outtextxy(115,2,str);
	}
}

void main(void)
{
// Declare your local variables here
// Variable used to store graphic display
// controller initialization data
GLCDINIT_t glcd_init_data;
char str1[10];
char str2[10];
// Input/Output Ports initialization
// Port A initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In 
DDRA=(0<<DDA7) | (0<<DDA6) | (0<<DDA5) | (0<<DDA4) | (0<<DDA3) | (0<<DDA2) | (0<<DDA1) | (0<<DDA0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=T Bit2=T Bit1=T Bit0=T 
PORTA=(0<<PORTA7) | (0<<PORTA6) | (0<<PORTA5) | (0<<PORTA4) | (0<<PORTA3) | (0<<PORTA2) | (0<<PORTA1) | (0<<PORTA0);

// Port B initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=Out Bit2=In Bit1=In Bit0=In 
DDRB=(0<<DDB7) | (0<<DDB6) | (0<<DDB5) | (0<<DDB4) | (1<<DDB3) | (0<<DDB2) | (0<<DDB1) | (0<<DDB0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=0 Bit2=T Bit1=T Bit0=T 
PORTB=(0<<PORTB7) | (0<<PORTB6) | (0<<PORTB5) | (0<<PORTB4) | (0<<PORTB3) | (0<<PORTB2) | (0<<PORTB1) | (0<<PORTB0);

// Port C initialization
// Function: Bit7=In Bit6=In Bit5=Out Bit4=Out Bit3=Out Bit2=Out Bit1=Out Bit0=Out 
DDRC=(0<<DDC7) | (0<<DDC6) | (1<<DDC5) | (1<<DDC4) | (1<<DDC3) | (1<<DDC2) | (1<<DDC1) | (1<<DDC0);
// State: Bit7=T Bit6=T Bit5=0 Bit4=0 Bit3=0 Bit2=0 Bit1=0 Bit0=0 
PORTC=(0<<PORTC7) | (0<<PORTC6) | (0<<PORTC5) | (0<<PORTC4) | (0<<PORTC3) | (0<<PORTC2) | (0<<PORTC1) | (0<<PORTC0);

// Port D initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In 
DDRD=(0<<DDD7) | (0<<DDD6) | (0<<DDD5) | (0<<DDD4) | (0<<DDD3) | (0<<DDD2) | (0<<DDD1) | (0<<DDD0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=T Bit2=T Bit1=T Bit0=T 
PORTD=(0<<PORTD7) | (0<<PORTD6) | (0<<PORTD5) | (0<<PORTD4) | (0<<PORTD3) | (0<<PORTD2) | (0<<PORTD1) | (0<<PORTD0);

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 125.000 kHz
// Mode: Fast PWM top=0xFF
// OC0 output: Non-Inverted PWM
// Timer Period: 2.048 ms
// Output Pulse(s):
// OC0 Period: 2.048 ms Width: 0 us
TCCR0=(1<<WGM00) | (1<<COM01) | (0<<COM00) | (1<<WGM01) | (0<<CS02) | (1<<CS01) | (1<<CS00);
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer1 Stopped
// Mode: Normal top=0xFFFF
// OC1A output: Disconnected
// OC1B output: Disconnected
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0<<AS2;
TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (0<<CS22) | (0<<CS21) | (0<<CS20);
TCNT2=0x00;
OCR2=0x00;


// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=(0<<OCIE2) | (1<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=(0<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
MCUCSR=(0<<ISC2);

// USART initialization
// USART disabled
UCSRB=(0<<RXCIE) | (0<<TXCIE) | (0<<UDRIE) | (0<<RXEN) | (0<<TXEN) | (0<<UCSZ2) | (0<<RXB8) | (0<<TXB8);

// Analog Comparator initialization
// Analog Comparator: Off
// The Analog Comparator's positive input is
// connected to the AIN0 pin
// The Analog Comparator's negative input is
// connected to the AIN1 pin
ACSR=(1<<ACD) | (0<<ACBG) | (0<<ACO) | (0<<ACI) | (0<<ACIE) | (0<<ACIC) | (0<<ACIS1) | (0<<ACIS0);
SFIOR=(0<<ACME);

// ADC initialization
// ADC disabled
ADCSRA=(0<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (0<<ADPS2) | (0<<ADPS1) | (0<<ADPS0);

// SPI initialization
// SPI disabled
SPCR=(0<<SPIE) | (0<<SPE) | (0<<DORD) | (0<<MSTR) | (0<<CPOL) | (0<<CPHA) | (0<<SPR1) | (0<<SPR0);

// TWI initialization
// TWI disabled
TWCR=(0<<TWEA) | (0<<TWSTA) | (0<<TWSTO) | (0<<TWEN) | (0<<TWIE);

// Graphic Display Controller initialization
// The KS0108 connections are specified in the
// Project|Configure|C Compiler|Libraries|Graphic Display menu:
// DB0 - PORTA Bit 0
// DB1 - PORTA Bit 1
// DB2 - PORTA Bit 2
// DB3 - PORTA Bit 3
// DB4 - PORTA Bit 4
// DB5 - PORTA Bit 5
// DB6 - PORTA Bit 6
// DB7 - PORTA Bit 7
// E - PORTB Bit 0
// RD /WR - PORTB Bit 1
// RS - PORTB Bit 2
// /RST - PORTB Bit 4
// /CS1 - PORTB Bit 5
// /CS2 - PORTB Bit 6

// Specify the current font for displaying text
glcd_init_data.font=font5x7;
// No function is used for reading
// image data from external memory
glcd_init_data.readxmem=NULL;
// No function is used for writing
// image data to external memory
glcd_init_data.writexmem=NULL;

glcd_init(&glcd_init_data);

PORTD=0x0F;

while (1)
     {     
      
      int right=0,left=0;
      float num1;
      int rpm; 
      int count=0,oldrpm=0; 
      int x=0;              
      int temp=0;
      float a=0.98;   
      int i=0;
      PORTC=0x0F;
      glcd_clear();
      glcd_outtextf("press keys\n*direction*speed#\n");
      glcd_outtextf("1:left\n2:right\nkey_off:stop");

      
      
      while(1){
        
        delay_ms(10);
        PORTC.0=0;
        PORTC.1=1;
        PORTC.2=1;
        PORTC.3=1;
        if(PIND.0==0){
            glcd_outtextf("7");
            if(temp >= 1){
                temp*=10;
            }
            temp+=7;
        }
        if(PIND.1==0){
            glcd_outtextf("8");
            if(temp >= 1){
                temp*=10;
            }
            temp+=8;
        }
        if(PIND.2==0){
            glcd_outtextf("9");
            if(temp >= 1){
                temp*=10;
            }
            temp+=9;
        }
        
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=0;
        PORTC.2=1;
        PORTC.3=1;
         if(PIND.0==0){
            glcd_outtextf("4");
            if(temp >= 1){
                temp*=10;
            }
            temp+=4;
        }
        if(PIND.1==0){
            glcd_outtextf("5");
            if(temp >= 1){
                temp*=10;
            }
            temp+=5;
        }
        if(PIND.2==0){
            glcd_outtextf("6");
            if(temp >= 1){
                temp*=10;
            }
            temp+=6;
        }
        if(PIND.3==0){
            if(i==0) glcd_clear();
            glcd_outtextf("*");
            i++;
        }
        
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=1;
        PORTC.2=0;
        PORTC.3=1;
         if(PIND.0==0){
            glcd_outtextf("1");
            if(i==1) left=1;
            else{
                if(temp >= 1){
                    temp*=10;
                }
                temp+=1;
            }
        }
        if(PIND.1==0){
            glcd_outtextf("2");
            if(i==1) right=1;
            else{
                if(temp >= 1){
                    temp*=10;
                }
                temp+=2; 
            }
        }
        if(PIND.2==0){
            glcd_outtextf("3");
            if(temp >= 1){
                temp*=10;
            }
            temp+=3;
        }
        
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=1;
        PORTC.2=1;
        PORTC.3=0;
        
        if(PIND.1==0){
            glcd_outtextf("0");
            temp*=10;
        } 
        
        if(PIND.2==0){ 
            glcd_outtextf("#");
            delay_ms(20); 
            break;          
        } 
        
      }
      glcd_clear();
      itoa(temp,str1);
      OCR0=100;
      TCCR0=(1<<WGM00) | (1<<COM01) | (0<<COM00) | (1<<WGM01) | (1<<CS02) | (0<<CS01) | (0<<CS00);
      OCR0=50;
      
      
      glcd_outtextf("\nenter interval#:\n "); 
      
      
      while(1){
        
        delay_ms(10);
        PORTC.0=0;
        PORTC.1=1;
        PORTC.2=1;
        PORTC.3=1;
        if(PIND.0==0){
            glcd_outtextf("7");
            if(count >= 1){
                count*=10;
            }
            count+=7;
        }
        if(PIND.1==0){
            glcd_outtextf("8");
            if(count >= 1){
                count*=10;
            }
            count+=8;
        }
        if(PIND.2==0){
            glcd_outtextf("9");
            if(count >= 1){
                count*=10;
            }
            count+=9;
        }
        
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=0;
        PORTC.2=1;
        PORTC.3=1;
         if(PIND.0==0){
            glcd_outtextf("4");
            if(count >= 1){
                count*=10;
            }
            count+=4;
        }
        if(PIND.1==0){
            glcd_outtextf("5");
            if(count >= 1){
                count*=10;
            }
            count+=5;
        }
        if(PIND.2==0){
            glcd_outtextf("6");
            if(count >= 1){
                count*=10;
            }
            count+=6;
        }
        
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=1;
        PORTC.2=0;
        PORTC.3=1;
         if(PIND.0==0){
            glcd_outtextf("1");
            if(count >= 1){
                count*=10;
            }
            count+=1;
        }
        if(PIND.1==0){
            glcd_outtextf("2");
            if(count >= 1){
                count*=10;
            }
            count+=2;
        }
        if(PIND.2==0){
            glcd_outtextf("3");
            if(count >= 1){
                count*=10;
            }
            count+=3;
        }
        
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=1;
        PORTC.2=1;
        PORTC.3=0;
        if(PIND.1==0){
            glcd_outtextf("0");
            count*=10;
        }
        if(PIND.2==0){ 
            glcd_outtextf("#");
            delay_ms(20); 
            break;          
        }  
      } 
      glcd_clear();
      itoa(count,str2);
      glcd_outtextf("user speed:");
      glcd_outtext(str1);
      glcd_outtextf("\n");
      glcd_outtextf("user interval:");
      glcd_outtext(str2);
      
     // TCCR0=0x00;
      #asm("sei")
      TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (0<<CS22) | (1<<CS21) | (0<<CS20);
      
      
      if(right == 1){ 
        
        PORTC.4=1;
        PORTC.5=0;
      }
      if(left == 1){
        
        PORTC.4=0;
        PORTC.5=1;
      }
        
      delay_ms(200);

            
      OCR1AH=0xFF;
      OCR1AL=0xFF;

      
      while(1){ 

        delay_ms(500);
        TCNT1=0;
        while(PIND.7 == 0);  
        TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (1<<WGM12) | (1<<CS12) | (0<<CS11) | (1<<CS10);
        while(PIND.7 == 1);      
        while(PIND.7 == 0);
        TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
        
        num1=TCNT1;
        TCNT1=0X00;
        num1=num1*0.0000512;
        num1=1/num1;
        rpm=num1;
        rpm/=10; 
        itoa(rpm,str1);
        glcd_outtextxy(110,55,str1);
        if(second1==count){
            glcd_setpixel(x,64-(rpm-oldrpm));
            x+=5;
            second1=0;
        }
         oldrpm=rpm;
        
        if(fabs(temp-rpm)>2) OCR0=a*(temp-rpm)+OCR0;
        delay_ms(10);
        PORTC.0=1;
        PORTC.1=1;
        PORTC.2=1;
        PORTC.3=0;
        
        if(PIND.0==0){
            glcd_clear();
            break;
        } 

        
                  
      }
      
     
    }
}